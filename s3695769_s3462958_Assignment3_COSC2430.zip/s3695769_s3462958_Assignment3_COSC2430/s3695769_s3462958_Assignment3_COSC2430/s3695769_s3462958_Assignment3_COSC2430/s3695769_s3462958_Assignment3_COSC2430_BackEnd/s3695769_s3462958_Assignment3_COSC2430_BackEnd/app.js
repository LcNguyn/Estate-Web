//import libraries
var express = require('express');
var bodyParser = require('body-parser');
var mongo = require('mongodb');
var monk = require('monk');
var path = require('path');

//create neccessary objects
var app = express();
var router = express.Router();

//you need to update wp with your own database name
var db = monk('localhost:27017/wp');

var date = new Date().toLocaleString('en-US', { timeZone: 'Asia/Ho_Chi_Minh' })

//use objects in app
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(function (req, res, next) {
        req.db = db;
        next();
});

//CORS middleware
app.use(function (req, res, next) {
        res.header('Access-Control-Allow-Origin', '*');
        res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
        res.header('Access-Control-Allow-Headers', 'Content-Type');

        next();
})

app.use('/', router);

//realestatestes

router.get('/realestates', function (req, res) {
        req.db.collection('realestates').find({}, { "limit": 100000000 }, function (e, docs) {
                res.json(docs);
        });
});

router.get('/realestates/user/:username', function (req, res) {
        req.db.collection('realestates').find({ user: req.params.username }, { "limit": 100000000 }, function (e, docs) {
                if (docs.length == 0) {
                        console.log(null)
                }
                else {
                        res.json(docs)
                }
        })
})

router.post('/realestates/user', function (req, res) {
        if (req.body.user) {
                req.db.collection('realestates').insert({
                        id: req.body.id,
                        title: req.body.title,
                        price: req.body.price,
                        area: req.body.area,
                        bedrooms: req.body.bedrooms,
                        floors: req.body.floors,
                        direction: req.body.direction,
                        contactInfo: req.body.contactInfo,
                        address: req.body.address,
                        postDate: req.body.postDate,
                        expiredDate: req.body.expiredDate,
                        imageUrl: req.body.imageUrl,
                        project: req.body.project,
                        user: req.body.user,
                        date: new Date().getTime().toLocaleString('en-US', { timeZone: 'Asia/Ho_Chi_Minh' })
                }, function (e, docs) { res.json(docs) })
        }
        else { res.json("Unauthorized access") }
})

router.get('/realestates/:id', function (req, res) {
        req.db.collection('realestates').findOne({ _id: req.params.id }, function (e, doc) {
                res.json(doc);
        })
});

router.delete('/realestates/:id', function (req, res) {
        req.db.collection('realestates').remove({ _id: req.params.id }, function (e, doc) {
                res.json(doc)
        })
});


router.put('/realestates/', function (req, res) {
        if (req.body.user) {
                req.db.collection('realestates').update({ _id: req.body._id }, {
                        id: req.body.id,
                        title: req.body.title,
                        price: req.body.price,
                        area: req.body.area,
                        bedrooms: req.body.bedrooms,
                        floors: req.body.floors,
                        direction: req.body.direction,
                        contactInfo: req.body.contactInfo,
                        address: req.body.address,
                        postDate: req.body.postDate,
                        expiredDate: req.body.expiredDate,
                        imageUrl: req.body.imageUrl,
                        project: req.body.project,
                        user: req.body.user,
                        date: date
                });

                req.db.collection('realestates').findOne({ _id: req.body._id }, function (e, doc) {
                        res.json(doc);
                })
        }
        else {
                res.json("Unauthorized access")
        }
});

//Projects

router.get('/projects', function (req, res) {
        req.db.collection('projects').find({}, { "limit": 100000000 }, function (e, docs) {
                res.json(docs)
        })
})

router.get('/projects/user/:userID', function (req, res) {
        req.db.collection('projects').find({ user: req.params.userID }, { "limit": 100000000 }, function (e, docs) {
                if (docs.length == 0) {
                        console.log(null)
                }
                else {
                        res.json(docs)
                }
        })
})

router.post('/projects/user', function (req, res) {
        if (req.body.user) {
                req.db.collection('projects').insert({
                        id: req.body.id,
                        name: req.body.name,
                        owner: req.body.owner,
                        type: req.body.type,
                        totalArea: req.body.totalArea,
                        endYear: req.body.endYear,
                        user: req.body.user
                }, function (e, docs) { res.json(docs) })
        }
        else { res.json("Unauthorized access") }
})

router.get('/projects/:id', function (req, res) {
        req.db.collection('projects').findOne({ _id: req.params.id }, function (e, doc) {
                res.json(doc);
        })
});

router.delete('/projects/:id', function (req, res) {
        req.db.collection('projects').remove({ _id: req.params.id }, function (e, doc) {
                res.json(doc)
        })
});

router.put('/projects/', function (req, res) {
        if (req.body.user) {
                req.db.collection('projects').update({ _id: req.body._id }, {
                        id: req.body.id,
                        name: req.body.name,
                        owner: req.body.owner,
                        type: req.body.type,
                        totalArea: req.body.totalArea,
                        endYear: req.body.endYear,
                        user: req.body.user
                });

                req.db.collection('projects').findOne({ _id: req.body._id }, function (e, doc) {
                        res.json(doc);
                })
        }
        else { res.json("Unauthorized access") }
});


//Login

app.post('/register', function (req, res) {
        req.db.collection('users').find({ username: req.body.username }, function (e, docs) {
                if (docs.length === 0) {
                        req.db.collection('users').insert(req.body, function (e, docs) {
                                res.json({ "registration": "successful" })
                        })
                }
                else {
                        res.json({ "registration": "failed" })
                }
        })
})

app.post('/login', function (req, res) {
        req.db.collection('users').find({ username: req.body.username, password: req.body.password }, function (err, docs) {
                if (docs.length == 0) {
                        res.json({ "authorize": "false" })
                }
                else {
                        res.json({ "authorize": "true" })
                }
        })
})


//Filter
app.post('/realestates/filter', function (req, res) {
        req.db.collection('realestates').find({
                $or: [
                        { price: { $gte: req.body.minPrice, $lte: req.body.maxPrice } },
                        { area: { $gte: req.body.minArea, $lte: req.body.maxArea } },
                        { bedrooms: { $gte: req.body.minBedrooms, $lte: req.body.maxBedrooms } },
                        { floors: { $gte: req.body.minFloors, $lte: req.body.maxFloors } },
                ]
        }, function (e, docs) {
                res.json(docs)
        })
})

//products

router.get('/products', function (req, res) {
        req.db.collection('products').find({}, { "limit": 100000000 }, function (e, docs) {
                res.json(docs);
        });
});

router.post('/products', function (req, res) {
        req.db.collection('products').insert({
                id: req.body.id,
                name: req.body.name,
                price: req.body.price,
                description: req.body.description,
                brand: req.body.brand,
                producer: req.body.producer,
                imageUrl: req.body.imageUrl,
                productType: req.body.productType

        }, function (e, docs) { res.json(docs) })

})

router.get('/products/:id', function (req, res) {
        req.db.collection('products').findOne({ _id: req.params.id }, function (e, doc) {
                res.json(doc);
        })
});

router.delete('/products/:id', function (req, res) {
        req.db.collection('products').remove({ _id: req.params.id }, function (e, doc) {
                res.json(doc)
        })
});


router.put('/products/', function (req, res) {
        req.db.collection('products').update({ _id: req.body._id }, {
                id: req.body.id,
                name: req.body.name,
                price: req.body.price,
                description: req.body.description,
                brand: req.body.brand,
                producer: req.body.producer,
                imageUrl: req.body.imageUrl,
                productType: req.body.productType
        });

        req.db.collection('products').findOne({ _id: req.body._id }, function (e, doc) {
                res.json(doc);
        })

});

//productTypes

router.get('/productTypes', function (req, res) {
        req.db.collection('productTypes').find({}, { "limit": 100000000 }, function (e, docs) {
                res.json(docs)
        })
})

router.post('/productTypes', function (req, res) {
        req.db.collection('productTypes').insert({
                id: req.body.id,
                name: req.body.name
        }, function (e, docs) { res.json(docs) })

})

router.get('/productTypes/:id', function (req, res) {
        req.db.collection('productTypes').findOne({ _id: req.params.id }, function (e, doc) {
                res.json(doc);
        })
});

router.delete('/productTypes/:id', function (req, res) {
        req.db.collection('productTypes').remove({ _id: req.params.id }, function (e, doc) {
                res.json(doc)
        })
});

router.put('/productTypes/', function (req, res) {
        req.db.collection('productTypes').update({ _id: req.body._id }, {
                id: req.body.id,
                name: req.body.name
        });

        req.db.collection('productTypes').findOne({ _id: req.body._id }, function (e, doc) {
                res.json(doc);
        })

});


//Login

app.post('/register', function (req, res) {
        req.db.collection('users').find({ username: req.body.username }, function (e, docs) {
                if (docs.length === 0) {
                        req.db.collection('users').insert(req.body, function (e, docs) {
                                res.json({ "registration": "successful" })
                        })
                }
                else {
                        res.json({ "registration": "failed" })
                }
        })
})

app.post('/login', function (req, res) {
        req.db.collection('users').find({ username: req.body.username, password: req.body.password }, function (err, docs) {
                if (docs.length == 0) {
                        res.json({ "authorize": "false" })
                }
                else {
                        res.json({ "authorize": "true" })
                }
        })
})


//Filter
app.post('/products/filter', function (req, res) {
        req.db.collection('products').find({
                $or: [
                        { price: { $gte: req.body.minPrice, $lte: req.body.maxPrice } },
                        { area: { $gte: req.body.minArea, $lte: req.body.maxArea } },
                        { bedrooms: { $gte: req.body.minBedrooms, $lte: req.body.maxBedrooms } },
                        { floors: { $gte: req.body.minFloors, $lte: req.body.maxFloors } },
                ]
        }, function (e, docs) {
                res.json(docs)
        })
})

app.get('/', (req, res) => res.send('Backend using MongoDb currently listening on port 3000. Add "/realestatestes", "/projects" to see more.'));
app.listen(3000, () => console.log('Backend using MongoDb currently listening on port 3000. Add "/realestatestes", "/projects" to see more.'));