export function fetchAllProjects() {
    return function (dispatch) {
        fetch('http://157.230.43.81:3000/projects')
            .then((res) => { return res.json() })
            .then((data) => {
                dispatch({
                    type: 'FETCH_ALL_PROJECTS',
                    payload: data
                })
            })
    }
}

export function fetchAllAds() {
    return function (dispatch) {
        fetch(`http://157.230.43.81:3000/realestates`)
            .then((res) => { return res.json() })
            .then((data) => {
                dispatch({
                    type: 'FETCH_ALL_ADS',
                    payload: data
                })
            })
    }
}

