import React, { Component } from 'react'
import Navigation from '../etc/Navigation.jsx'

export default class About extends Component {
    render() {
        return (
            <div className="about" >
                <Navigation />
                <h1 className="about-h1" >Welcome to our website</h1>
            <div className="container" style={{color:"white"}} >
                <div className="row" align="center">
                <div className="avatar col-lg-3 col-md-3 col-sm-3 text-center"  ></div>
                
                        <div className="avatar col-lg-3 col-md-3 col-sm-3 text-center"  >
                            <div className="row">
                                <div >
                                    <h2>Nguyen Tuan Loc</h2>

                                    <div><small>ID: s3695769</small></div>
                                   
                                    <div><small>Contact: s3695769@rmit.edu.vn</small></div>
                                </div>
                            </div>
                        </div>

                        <div className="avatar col-lg-3 col-md-3 col-sm-3 text-center"  >
                            <div className="row">
                                <div >
                                    <h2>Nguyen Son Tung</h2>

                                    <div><small>ID: s3462958</small></div>
                                    <div><small>Contact: s3462958@rmit.edu.vn</small></div>
                                </div>  
                            </div>
                        </div>
                        <div className="avatar col-lg-3 col-md-3 col-sm-3 text-center" style={{paddingLeft:"150px"}} ></div>
                </div>
            </div>
            
            </div>
        )
    }
}
