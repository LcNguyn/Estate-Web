import React, { Component } from 'react'
import EstateForm from './EstateForm.jsx'
import Navigation from '../etc/Navigation.jsx'
import { Link } from 'react-router-dom'

export default class MyEstates extends Component {
    constructor(props) {
        super(props)
    }


    componentDidMount() {
        this.props.fetchUsersAds(sessionStorage.getItem('state'))
        this.props.fetchAllProjects()
    }

    handleEdit(_id) {
        this.props.getAdvert(_id)
    }

    render() {
        if (sessionStorage.getItem('state') === null || sessionStorage.getItem('state') === undefined) {
            return (
                <div className="need-signin" align="center">
                    <h1>We don't know who your are :((<p></p> Click <Link to="/signin">here</Link> to sign in.</h1>
                    <Link to="/home" >
                        <button type="button" className="btn btn-home">
                            <i className="fas fa-home"></i>
                        </button>
                    </Link>
                </div>
            )
        }

        else {
            return (
                <div>
                    <Navigation />
                    <br />

                    <button onClick={() => { this.EstateForm.clearForm() }} type="button" className="btn btn-add" data-toggle="modal" data-target="#exampleModal">
                        <i className="fas fa-plus"></i>
                    </button>

                    <div className="row">
                        <div className="modal fade bd-example-modal-lg col-sm-12" id="exampleModal" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div className="modal-dialog" role="document">
                                <div className="modal-content">
                                    <div className="modal-header">
                                        <h5 className="modal-title" id="exampleModalLabel">Estate Form</h5>
                                        <button onClick={() => { this.EstateForm.clearForm() }} type="button" className="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div className="mmmodal-body modal-body">
                                        <EstateForm
                                            ref={instance => { this.EstateForm = instance }}
                                            editAdvert={this.props.editAdvert}
                                            addAdvert={(ad) => this.props.addAdvert(ad)}
                                            updateAdvert={(ad) => this.props.updateAdvert(ad)}
                                            projects={this.props.projects}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                   <div className = "container fluid">
                   <div className="row">
                        {this.props.userAdverts.map((ad, index) =>
                            <div className="reccol col-sm-3" key={index} >
                                <div className="estate-card card border-lightgrey mb-3 ">
                                    <img className="card-img-top" style={{maxHeight:"100%", maxWidth:"100%", height:"250px", width:"250px"}} src={ad.imageUrl[0]} alt="" />
                                    <div className="card-body grid-body2">
                                        <div>
                                            <h5 className="card-title title-card">{ad.title}</h5>
                                            <p className="card-text" >
                                                {/* <b>ID:</b> {ad.id}<br /> */}
                                                {/* <b>Title:</b> {ad.title}<br /> */}
                                                <b > </b> ${ad.price} per night<br />
                                                <b></b> {ad.area} m²<br />
                                                <b></b>{ad.bedrooms} bedrooms<br />
                                                <b></b>{ad.floors} floors<br />
                                                <b></b>In {ad.address}<br />
                                                {/* <b>Direction: </b>{ad.direction}<br /> */}
                                            </p>
                                            <div align = "center">
                                                <a role="button" data-toggle="modal" data-target="#exampleModal" className="edit-button btn btn-warning" onClick={() => this.handleEdit(ad._id)}>
                                                    <i className="fas fa-edit"></i>
                                                </a>
                                                &nbsp;
                                                &nbsp;
                                                <a role="button" className="delete-button btn btn-danger"  onClick={(_id) => this.props.deleteAdvert(ad._id)}><i className="fas fa-trash-alt"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                   </div>
                </div>
            )
        }
    }
}
