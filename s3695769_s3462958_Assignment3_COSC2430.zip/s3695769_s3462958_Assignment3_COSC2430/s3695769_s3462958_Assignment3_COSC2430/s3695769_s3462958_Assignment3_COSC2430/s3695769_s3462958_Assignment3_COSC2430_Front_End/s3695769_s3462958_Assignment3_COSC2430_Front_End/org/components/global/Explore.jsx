import React from 'react'
import Navigation from '../etc/Navigation.jsx';
import Pagination from '../global/Pagination.jsx'
import GlobalGrid from '../global/GlobalGrid.jsx';
import { NavLink } from 'react-router-dom'


export default class Explore extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            currentAds: this.props.adverts,
            listExp: [],
            listFav: [],
            modalAdvert: {},
            fields: {
                "minPrice": "",
                "maxPrice": "3000",
                "minArea": "",
                "maxArea": "1000",
                "minBedrooms": "",
                "maxBedrooms": "7",
                "minFloors": "",
                "maxFloors": "5"
            },
            errors: {},

        };
        this.resetForm = this.resetForm.bind(this)


    }

    resetForm() {
        let fields = this.state.fields
        fields["_id"] = "";
        fields["id"] = "";
        fields["title"] = "";
        fields["price"] = "";
        fields["area"] = "";
        fields["bedrooms"] = "";
        fields["floors"] = "";
        fields["direction"] = "";
        fields["contactInfo"] = "";
        fields["address"] = "";
        fields["postDate"] = "";
        fields["expiredDate"] = "";
        fields["imageUrl"] = "";
        fields["project"] = "";
        fields["user"] = sessionStorage.getItem('state')
        this.setState({ fields: fields })
    }

    componentDidUpdate() {
        let nextModal = this.props.editAdvert

        if (nextModal != this.state.modalAdvert) {
            this.setState({ modalAdvert: nextModal })
        }

    }

    componentWillMount() {
        this.props.fetchAllAds()
        this.props.fetchAllProjects()
    }

    componentWillReceiveProps(nextProps) {

        this.setState({ currentAds: nextProps.adverts })
        let expSliced = nextProps.adverts.slice(0, 3)
        this.setState({ listExp: expSliced })
        let favSliced = nextProps.adverts.slice(6, 11)
        this.setState({ listFav: favSliced })


        if (nextProps.filteredEstates.length !== 0) {
            this.setState({ currentAds: nextProps.filteredEstates })
        }


    }

    filterByPrice(filter) {
        if (filter === 'LO_TO_HI') {
            let lowToHigh = this.props.adverts.sort(function (a, b) {
                return parseFloat(a.price) - parseFloat(b.price);
            });
            this.setState({ currentAds: lowToHigh })
        }
        else if (filter === 'HI_TO_LO') {
            let highToLow = this.props.adverts.sort(function (a, b) {
                return parseFloat(b.price) - parseFloat(a.price);
            });
            this.setState({ currentAds: highToLow })

        }
    }

    filterByDemand(filter) {
        if (filter === 'BELOW_500') {
            let below500 = this.props.adverts.filter((ad) => ad.area <= 500)
            this.setState({ currentAds: below500 })
        }

        else if (filter === 'OVER_500') {
            let over500 = this.props.adverts.filter((ad) => ad.area > 500)
            this.setState({ currentAds: over500 })
        }

        else if (filter === 'BEDROOMS_1_3') {
            let bedrooms_1_3 = this.props.adverts.filter((ad) => ad.bedrooms >= 1 && ad.bedrooms <= 3)
            this.setState({ currentAds: bedrooms_1_3 })
        }

        else if (filter === 'BEDROOMS_3_') {
            let bedrooms_3_ = this.props.adverts.filter((ad) => ad.bedrooms > 3)
            this.setState({ currentAds: bedrooms_3_ })
        }

        else if (filter === 'FLOORS_1_3') {
            let floors_1_3 = this.props.adverts.filter((ad) => ad.floors >= 1 && ad.floors <= 3)
            this.setState({ currentAds: floors_1_3 })
        }

        else if (filter === 'FLOORS_3_') {
            let floors_3_ = this.props.adverts.filter((ad) => ad.floors > 3)
            this.setState({ currentAds: floors_3_ })
        }

        else {
            let category = this.props.adverts.filter((ad) => ad.project == filter)
            this.setState({ currentAds: category })
        }


    }

    onFind(e) {
        var target = e.target
        var name = target.name
        var value = target.value

        this.setState({
            [name]: value
        })

        var loweredkeyword = this.state.keyword.toLowerCase()
        if (this.state.keyword === undefined) {
            this.setState({ currentAds: this.props.adverts })
        }
        this.setState({
            currentAds: this.props.adverts.filter(ad =>
                ad.title.toLowerCase().indexOf(loweredkeyword) !== -1
            )
        })
    }

    onView(_id) {
        this.props.getAdvert(_id)
    }

    render() {


        return (
            <div>

                <header className="header">
                    <Navigation />


                    <div className="filter-box block-filter">

                        <div className="filter-row row">
                            <div className="col-lg-1 col-md-1 col-sm-1"></div>
                            <div className="col-lg-10 col-lg-10 col-sm-10">
                                <div className="row">
                                    <div id="1" className="col-sm-1 col-md-1" style={{ marginLeft: "2px" }}>
                                        <div className="dropdown">
                                            <button className="filter-button btn  " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Price
                </button>
                                            <div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <a className="dropdown-item" role="button" onClick={() => this.filterByPrice('HI_TO_LO')}>High to Low</a>
                                                <a className="dropdown-item" role="button" onClick={() => this.filterByPrice('LO_TO_HI')}>Low to High</a>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="2" className='col-sm-1 col-md-1' style={{ marginLeft: "2px" }}>
                                        <div className="dropdown">
                                            <button className="filter-button btn " type="button" id="dropDownAreaButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Area
                </button>
                                            <div className="dropdown-menu" aria-labelledby="dropDownAreaButton">
                                                <a className="dropdown-item" role="button" onClick={() => this.filterByDemand('BELOW_500')} >500 or Lower</a>
                                                <a className="dropdown-item" role="button" onClick={() => this.filterByDemand('OVER_500')} >Over 500</a>

                                            </div>
                                        </div>
                                    </div>

                                    <div id="3" className='col-sm-1 col-md-1' style={{ marginLeft: "2px" }}>
                                        <div className="dropdown">
                                            <button className=" filter-button btn" type="button" id="dropDownCategoryButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Bedrooms
                </button>
                                            <div className="dropdown-menu" aria-labelledby="dropDownCategoryButton">
                                                <a className="dropdown-item" role="button" onClick={() => this.filterByDemand('BEDROOMS_1_3')} >1-3</a>
                                                <a className="dropdown-item" role="button" onClick={() => this.filterByDemand('BEDROOMS_3_')} >More than 3</a>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="4" className='col-sm-1 col-md-1' style={{ marginLeft: "2px" }}>
                                        <div className="dropdown">
                                            <button className=" filter-button btn" type="button" id="dropDownFloorsButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Floors
                </button>
                                            <div className="dropdown-menu" aria-labelledby="dropDownFloorsButton">
                                                <a className="dropdown-item" role="button" onClick={() => this.filterByDemand('FLOORS_1_3')} >1-3</a>
                                                <a className="dropdown-item" role="button" onClick={() => this.filterByDemand('FLOORS_3_')} >More than 3</a>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="5" className='col-sm-1 col-md-1' style={{ marginLeft: "2px" }}>
                                        <div className="dropdown">
                                            <button className=" filter-button btn  " type="button" id="dropDownProjectButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Project
                </button>
                                            <div className="dropdown-menu" aria-labelledby="dropDownProjectButton">
                                                {this.props.projects.map((project, index) => {
                                                    return <a key={index} role="button" className="dropdown-item" onClick={() => this.filterByDemand(project.name)} >{project.name}</a>
                                                })}
                                            </div>
                                        </div>
                                    </div>

                                    <div id="6" className='six col-sm-6 col-md-6' style={{ marginLeft: "2px" }}>
                                        <div className="input-group add-on searchContainer">
                                            <i style={{ fontSize: "25px", paddingTop: "2px" }} className="fas fa-search searchIcon" /> &nbsp;
                <input type="text" className="form-control" placeholder="Search For Title" name="keyword" id="srch-term" value={this.state.keyword} onChange={this.onFind.bind(this)} />
                                            &nbsp;
                    <button className="del-btn btn btn-default" onClick={this.clearKey}><i className="del-btn fas fa-times"></i></button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>

                </header>

                <main className="main">

                    <div className="imagecontainer">

                        <img className="d-block w-100" src="https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1650&q=80" alt="Snow" style={{ height: "100vh", maxWidth: "100vw" }} />
                        <div className="imageInner">
                            <NavLink to="/home" >    <button className="learnmore btn">LEARN MORE      &nbsp;<i className="fas fa-chevron-right"></i></button> </NavLink>

                        </div>

                    </div>

                    <div className="container" style={{ paddingTop: "50px" }}>
                        <h4 className="h1" >Explore experience</h4>
                        <h6 className="h2" >Browsing beautiful homes with all the comforts of home and more</h6>
                        <div className="row">
                            {this.state.listExp.map((ad, index) =>
                                <div className="imageContainer col-lg-4 col-md-4 col-sm-4" key={index}>
                                    <img onClick={this.onView.bind(this, ad._id)} data-toggle="modal" className="cover" data-target="#exampleModalCenter" style={{ height: "100%", width: "90%" }} src={ad.imageUrl[0]} />

                                    <div onClick={this.onView.bind(this, ad._id)} data-toggle="modal" data-target="#exampleModalCenter" className="imageInner" align="center" >
                                        <p className="title-card">{ad.title}</p>
                                    </div>
                                </div>
                            )}

                        </div>
                        <br />
                        <br />

                        <h4 className="h1" style={{ marginTop: "50px" }}>Favourite</h4>
                        <h6 className="h2">Find the top-rate home with all recommendations and place information </h6>
                        <div className=" row" >
                            {this.state.listFav.map((ad, index) =>
                                <div className="fav-item card border-lightgrey mb-3 estate-card" style={{ marginLeft: "5px" }} key={index}>
                                    <div className="row">

                                        <div className="col-lg-6 col-md-6 col-sm-6">
                                            <img onClick={this.onView.bind(this, ad._id)} data-toggle="modal" data-target="#exampleModalCenter" className="cover card-img-top" style={{ paddingLeft: "0px", height: "90px", width: "90px" }} src={ad.imageUrl[0]} alt="" />
                                        </div>
                                        <div onClick={this.onView.bind(this, ad._id)} data-toggle="modal" data-target="#exampleModalCenter" className="cover col-lg-6 col-md-6 col-sm-6" style={{ width: "120px", paddingLeft: "0px" }}>
                                            <div>
                                                <b style={{ fontSize: "15px" }}>{ad.title}</b>
                                            </div>
                                            <div>
                                                <small>${ad.price} per night</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            )}
                        </div>
                        <br />
                        <br />

                        <div className="service" style={{ paddingTop: "30px" }}>
                            <div className="row">
                                <div className="service-item col-sm-4 col-lg-4">
                                    <i className="fas fa-comments"></i>
                                    <h4>24/7 customer support</h4>
                                    <small >Day or night, we're here for you. Talk yo our support team anywhere in the world, any hour of day.</small>

                                </div>
                                <div className="col-sm-4 col-lg-4">
                                    <i className="fas fa-home"></i>
                                    <h4>Global hospitality standards</h4>
                                    <small>Guests review their hosts after each stay. All hosts must maintain a minimum rating and our hospitality standards to be on Estulo.</small>

                                </div>
                                <div className="col-sm-4 col-lg-4">
                                    <i className="far fa-star"></i>
                                    <h4>5-star hosts</h4>
                                    <small>From fresh-pressed sheets to tips on where to get the best brunch, our hosts are full of local hospitality.</small>

                                </div>

                            </div>
                        </div>


                        <h4 className="h1" style={{ marginTop: "50px" }}>All Available Home</h4>
                        <h6 className="h2">Have fun with browsing your dream home</h6>
                    </div>


                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-12">
                                <GlobalGrid
                                    editAdvert={this.props.editAdvert}
                                    getAdvert={(_id) => this.props.getAdvert(_id)}
                                    adverts={this.state.currentAds}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="modal fade" id="exampleModalCenter" tabIndex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                        <div className="modal-dialog modal-dialog-centered grid-modal-wrapper" role="document">
                            <div className="modal-content content-grid">
                                <div className="modal-header">
                                    <h3 className="modal-title">{this.state.modalAdvert.title}</h3>
                                    <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div className="mmodal-body modal-body">
                                    <div className="container-fluid">
                                        <div className="row">
                                            <div className="col-sm-4">
                                                {/* <img id="grid-image" src={this.state.modalAdvert.imageUrl} alt="" /> */}
                                            </div>
                                            &nbsp;
                                            &nbsp;
                                                <div className="col-sm-4">
                                                <div className="modal-text">
                                                    <p className="card-text" align="left" >
                                                        <b>ID: </b>{this.state.modalAdvert.id} <br />
                                                        <b>Price: </b> $ {this.state.modalAdvert.price}<br />
                                                        <b>Area:</b> {this.state.modalAdvert.area} m²<br />
                                                        <b>Bedrooms: </b>{this.state.modalAdvert.bedrooms}<br />
                                                        <b>Floors: </b>{this.state.modalAdvert.floors}<br />
                                                        <b>Direction: </b>{this.state.modalAdvert.direction}<br />
                                                        <b>Contact: </b><br />{this.state.modalAdvert.contactInfo}<br />
                                                        <b>Address: </b>{this.state.modalAdvert.address}<br />
                                                        <b>Date Posted: </b>{this.state.modalAdvert.postDate}<br />
                                                        <b>Date Expired: </b>{this.state.modalAdvert.expiredDate}<br />
                                                        <b>Project: </b>{this.state.modalAdvert.project}<br />
                                                    </p>
                                                </div>
                                                <div className="col-sm-4">
                                                    {/* <img id="grid-image" src={this.state.modalAdvert.imageUrl} alt="" /> */}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </main>

                <button type="button" className="footer-btn btn " data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                    <p>  <i className="far fa-question-circle"></i>  &nbsp;More information</p>
                </button>

                <div className="collapse" id="collapseExample">

                    <footer className="footer">
                        <div className="container">
                            <div className="footer-row row py-4 d-flex align-items-top">
                                <div className="footer-col col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                                    <h6 className="text-uppercase font-weight-bold">Discover</h6>
                                    {/* <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;"> */}
                                    <p>
                                        <a href="#">Trust and Safety</a>
                                    </p>
                                    <p>
                                        <a href="#">Travel Credit</a>
                                    </p>
                                    <p>
                                        <a href="#">Gift Cards</a>
                                    </p>
                                    <p>
                                        <a href="#">Estulo Citizen</a>
                                    </p>
                                    <p>
                                        <a href="#">Business Travel</a>
                                    </p>
                                </div>
                                <div className="footer-col col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                                    <h6 className="text-uppercase font-weight-bold">Estulo</h6>
                                    {/* <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;"> */}
                                    <p>
                                        <a href="#!">Careers</a>
                                    </p>
                                    <p>
                                        <a href="#!">Press</a>
                                    </p>
                                    <p>
                                        <a href="#!">Policies</a>
                                    </p>
                                    <p>
                                        <a href="#!">Help</a>
                                    </p>
                                </div>
                                <div className=" footer-col col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                                    <h6 className="text-uppercase font-weight-bold">Contact</h6>
                                    {/* <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;"> */}
                                    <p>
                                        <i className="fas fa-home mr-3"></i> RMIT University</p>
                                    <p>
                                        <i className="fas fa-envelope mr-3"></i> s3462958@rmit.edu.vn</p>
                                    <p>
                                        <i className="fas fa-envelope mr-3"></i> s3695769@rmit.edu.vn</p>
                                    <p>
                                        <i className="fas fa-phone mr-3"></i> + 01 234 567 88</p>
                                    <p>
                                        <i className="fas fa-print mr-3"></i> + 01 234 567 89</p>
                                </div>
                            </div>

                            <div className="footer-copyright text-center py-3">
                                <p>Estulo Copy Copyright &copy; 2019, All Rights Reserved</p>

                            </div>
                        </div>
                    </footer>
                </div>
            </div>
        )
    }
}