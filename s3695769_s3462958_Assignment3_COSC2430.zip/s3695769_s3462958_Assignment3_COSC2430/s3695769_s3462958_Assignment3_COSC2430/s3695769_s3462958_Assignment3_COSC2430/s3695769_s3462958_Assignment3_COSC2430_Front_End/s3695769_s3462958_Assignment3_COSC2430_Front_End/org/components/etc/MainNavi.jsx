import React, { Component } from 'react'
import { NavLink } from 'react-router-dom'

export default class MainNavi extends Component {
    constructor(props) {
        super(props)
        this.state = {}
        this.signOut = this.signOut.bind(this)
    }

    signOut() {
        sessionStorage.clear()
    }

    render() {
        return (
            <div>
                <nav className="mainnavi navbar navbar-fixed-top navbar-expand-lg navbar-light bg-transparent ">
                    <li className="navbar-brand">
                        <NavLink to="/home" style={{ textDecoration: "none", color: "black", }}> &nbsp; <b className = "brand-icon" >ESTULO</b> &nbsp; </NavLink>
                    </li>

                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>

                    <div className="collapse navbar-collapse" id="navbarText">
                        <ul className="navbar-nav mr-auto">
                            <li className="nav-link" style={{ marginTop: "1.8%" }}>
                                <NavLink to="/home" style={{ textDecoration: "none", color: "black", }}><b className = "menu-button">Home</b></NavLink>
                            </li>
                            &nbsp;
                            &nbsp;
                            <li className="nav-link" style={{ marginTop: "1.8%" }}>
                                <NavLink to="/explore" style={{ textDecoration: "none", color: "black", }}><b className = "menu-button">Explore</b></NavLink>
                            </li>
                            &nbsp;
                            &nbsp;
                            <li className="nav-link" style={{ marginTop: "1.8%" }}>
                                <NavLink to="/myestates" style={{ textDecoration: "none", color: "black", }}><b className = "menu-button">My Estates</b></NavLink>
                            </li>
                            &nbsp;
                            &nbsp;
                            <li className="nav-link" style={{ marginTop: "1.8%" }}>
                                <NavLink to="/myprojects" style={{ textDecoration: "none", color: "black", }}><b className = "menu-button">My Projects</b></NavLink>
                            </li>
                            &nbsp;
                            &nbsp;
                            <li className="nav-link" style={{ marginTop: "1.8%" }}>
                                <NavLink to="/about" style={{ textDecoration: "none", color: "black", }}><b className = "menu-button">About</b></NavLink>
                            </li>
                        </ul>
                        <div className='logged-in form-inline mt-2 mt-md-0'>
                            {sessionStorage.getItem('state') ?
                                <div>
                                    <code  >User {sessionStorage.getItem('state')}</code> &nbsp; &nbsp;
                                    <NavLink style={{ textDecoration: "none", color: "white" }} to="/home"><button className="btn btn-nav-signout" onClick={this.signOut} >Sign Out</button></NavLink>
                                    
                                </div>
                                : <div>
                                     <NavLink to="/register" style={{ textDecoration: "none", color: "black", }}><b className = "menu-button">Sign Up</b></NavLink>
                                     &nbsp;
                            &nbsp;
                            <NavLink to="/signin" style={{ textDecoration: "none", color: "black", }}><b className = "menu-button">Log In</b></NavLink>

                                   
                                </div>
                            }
                        </div>
                    </div>
                </nav>
            </div>
        )
    }
}
