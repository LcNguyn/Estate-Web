import React from 'react';
import Pagination from './Pagination.jsx';

export default class Carousel_Item extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            pageOfItems: [],
            modalAdvert: {},
            slice4Items: [],

        };

        this.onChangePage = this.onChangePage.bind(this);
    }

    onChangePage(pageOfItems) {
        this.setState({ pageOfItems: pageOfItems });
    }

    componentWillReceiveProps(nextprops) {
         let sliced = nextprops.adverts.slice(0, 6)
        this.setState({ slice4Items: sliced })
    }

    componentDidUpdate() {
        let nextModal = this.props.editAdvert

        if (nextModal != this.state.modalAdvert) {
            this.setState({ modalAdvert: nextModal })
        }

    }


    onView(_id) {
        this.props.getAdvert(_id)
    }

    render() {
        return (
            <div>
                <div className="container" align= "center">
                    <div className="row" align= "center">
                        {this.state.slice4Items.map((ad, index) => {
                            return (
                                <div className="reccol col-sm-2" key={index} align= "center" >
                                    <div className="card border-lightgrey mb-3 text-center estate-card">
                                        
                                        <img onClick={this.onView.bind(this, ad._id)} data-toggle="modal" data-target="#exampleModalCenter" className=" card-img-top" className="cover" style={{  maxHeight: "100%", maxWidth: "100%", height: "260px", width: "500px" }} src={ad.imageUrl[0]} alt="" />
                                    
                                    </div>
                                </div>
                            )
                        })}

                        <br />

                        <div className="modal fade" id="exampleModalCenter" tabIndex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                            <div className="modal-dialog modal-dialog-centered grid-modal-wrapper" role="document">
                                <div className="modal-content content-grid">
                                    <div className="modal-header">
                                        <h3 className="modal-title">{this.state.modalAdvert.title}</h3>
                                        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div className="mmodal-body modal-body">
                                        <div className="container-fluid">
                                            <div className="row">
                                                <div className="col-sm-4">
                                                    {/* <img id="grid-image" src={this.state.modalAdvert.imageUrl} alt="" /> */}
                                                </div>
                                                &nbsp;
                                                &nbsp;
                                                <div className="col-sm-4">
                                                    <div className="modal-text">
                                                        <p className="card-text" align="left" >
                                                            <b>ID: </b>{this.state.modalAdvert.id} <br />
                                                            <b>Price: </b> $ {this.state.modalAdvert.price}<br />
                                                            <b>Area:</b> {this.state.modalAdvert.area} m²<br />
                                                            <b>Bedrooms: </b>{this.state.modalAdvert.bedrooms}<br />
                                                            <b>Floors: </b>{this.state.modalAdvert.floors}<br />
                                                            <b>Direction: </b>{this.state.modalAdvert.direction}<br />
                                                            <b>Contact: </b><br/>
                                                            {this.state.modalAdvert.contactInfo}<br />
                                                            <b>Address: </b>{this.state.modalAdvert.address}<br />
                                                            <b>Date Posted: </b>{this.state.modalAdvert.postDate}<br />
                                                            <b>Date Expired: </b>{this.state.modalAdvert.expiredDate}<br />
                                                            <b>Project: </b>{this.state.modalAdvert.project}<br />
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="col-sm-4">
                                                    {/* <img id="grid-image" src={this.state.modalAdvert.imageUrl} alt="" /> */}
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="modal-footer">
                                        <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <br />
                    {/* <Pagination pageSize={6} initialPage={1} items={this.props.adverts} onChangePage={this.onChangePage} /> */}
                </div>
            </div>
        );
    }
}
