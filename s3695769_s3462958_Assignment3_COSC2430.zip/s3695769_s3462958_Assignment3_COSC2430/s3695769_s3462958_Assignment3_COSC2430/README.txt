RMIT University Vietnam
  Course: COSC2430
  Semester: 2019A
  Assessment: Assignment 3 - Build a full stack web application
  Author: Nguyen Son Tung - Nguyen Tuan Loc
  ID: s3462958 && s3695769
  Created date: 15-05-2019
 
IP address
Frond-end:http://68.183.69.196/
Back-end: http://157.230.43.81:3000/realestates

Greeting !

We are development team of the a web application works as a real-estate portal that allow sellers to sell a real estate of different kind such as apartments, houses, villa, land etc. We name our website ESTULO

We've already created an account for professor to login our website with Username: Thanhthanh28 and Password: Thanhthanh28

<http://68.183.69.196 && http://68.183.69.196/home >:
The basic default homepage is available to all guests visit and look for home ads.
The first display will be all recommended home ads that suitable for users of the website.
Secondly, all ads in the web will be displayed in Grid View with Pagination at the bottom. To see detail of the ads, users simply click on the picture or button detail of the ads.
 
<http://68.183.69.196/explore>
With the button Explore and See More that link to Explore Page that contains all of those ads are display in grid view which supported by Search for ads title at search bar, 5 buttons Price, Area, number of Bedrooms,Floors and Projects for Filtering. Both will be display at the last section of the page. The first cover image help users to go back to the main page for understanding. The second sections of the page is Favourite ads that liked by most of website users. If users dont try filtering the ads, the last section will display all ads with pagination just like the homepage. All of images and button details on this page are using to see detail of the ad.

<http://68.183.69.196/about>
The last public page is about page, which contain of information and contacts of website development team members.

Last two page are: <http://68.183.69.196/myestates>, <http://68.183.69.196/myprojects>
Beside the public pages, other sites of our website are requiring user to login by their accounts. 
If they dont have an account yet, we have made a basic sign up page for them.
All users accounts are allow to create their own projects and they are able to manage their projects with all CRUD function which call by the + button at the right bottom of the page.

If users try to log into these private sites, the error will appear with recommendation of sign in or click on home button at the bottom right for getting back to the Home page.
  
The idea of building this website is coming from Airbnb.com so it might be a little bit similar. ^^!

Thanks for paying attention and Have a nice sem break ^^!!



