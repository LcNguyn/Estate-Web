import React from 'react';
import Pagination from './Pagination.jsx';

export default class GlobalGrid extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            pageOfItems: [],
            modalAdvert: {}
        };

        this.onChangePage = this.onChangePage.bind(this);
    }

    onChangePage(pageOfItems) {
        this.setState({ pageOfItems: pageOfItems });
    }

    componentWillReceiveProps(nextprops) {
        this.setState({ pageOfItems: nextprops.adverts })
    }

    componentDidUpdate() {
        let nextModal = this.props.editAdvert

        if (nextModal != this.state.modalAdvert) {
            this.setState({ modalAdvert: nextModal })
        }

    }


    onView(_id) {
        this.props.getAdvert(_id)
    }

    render() {
        return (
            <div>
                <div className="container">
                    <div className="row">
                        {this.state.pageOfItems.map((ad, index) => {
                            return (
                                <div className="reccol col-sm-3" key={index} >
                                    <div className="card mb-3 text-center estate-card">
                                        <img onClick={this.onView.bind(this, ad._id)} data-toggle="modal" data-target="#exampleModalCenter" className="cover card-img-top" style={{maxHeight:"100%", maxWidth:"100%", height:"180px", width:"300px"}} src={ad.imageUrl[0]} alt="" />
                                        <div onClick={this.onView.bind(this, ad._id)} data-toggle="modal" data-target="#exampleModalCenter" className="card-body grid-body">
                                            <div>
                                                <p className="card-text" align="left" >
                                                <b className = "address-card">{ad.address.toUpperCase()}</b><br />
                                                <b className= "title-card">{ad.title}</b>
                                                <br />                                                 
                                                    <b></b>${ad.price} per night
                                                    <br />
                                                    <b></b> {ad.area} m²
                                                     <br />
                                                </p>
                                                <button className="detail-btn btn btn-general" onClick={this.onView.bind(this, ad._id)} data-toggle="modal" data-target="#exampleModalCenter" >Details</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        })}

                        <br />

                        <div className="modal fade" id="exampleModalCenter" tabIndex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                            <div className="modal-dialog modal-dialog-centered grid-modal-wrapper" role="document">
                                <div className="modal-content content-grid">
                                    <div className="modal-header">
                                        <h3 className="modal-title">{this.state.modalAdvert.title}</h3>
                                        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div className="mmodal-body modal-body">
                                        <div className="container-fluid">
                                            <div className="row">
                                                <div className="col-sm-4">
                                                </div>
                                                &nbsp;
                                                &nbsp;
                                                <div className="col-sm-4">
                                                    <div className="modal-text">
                                                        <p className="card-text" align="left" >
                                                            <b>ID: </b>{this.state.modalAdvert.id} <br />
                                                            <b>Price: </b> $ {this.state.modalAdvert.price}<br />
                                                            <b>Area:</b> {this.state.modalAdvert.area} m²<br />
                                                            <b>Bedrooms: </b>{this.state.modalAdvert.bedrooms}<br />
                                                            <b>Floors: </b>{this.state.modalAdvert.floors}<br />
                                                            <b>Direction: </b>{this.state.modalAdvert.direction}<br />
                                                            <b>Contact: </b><br/>{this.state.modalAdvert.contactInfo}<br />
                                                            <b>Address: </b>{this.state.modalAdvert.address}<br />
                                                            <b>Date Posted: </b>{this.state.modalAdvert.postDate}<br />
                                                            <b>Date Expired: </b>{this.state.modalAdvert.expiredDate}<br />
                                                            <b>Project: </b>{this.state.modalAdvert.project}<br />
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="col-sm-4">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="modal-footer">
                                        <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <br />
                    <Pagination pageSize={8} initialPage={1} items={this.props.adverts} onChangePage={this.onChangePage} />
                </div>
            </div>
        );
    }
}
