import React, { Component } from 'react'
import {NavLink} from 'react-router-dom'

export default class PageNotFound extends Component {
  render() {
    return (
      <div className="error">
        <h2>Page not found...</h2>
        <br />
        <br/>
        <p>The page you're looking for does not exist. We're sorry for this inconvenience.</p>
        <p>Go back to <NavLink to="/home">home</NavLink>.</p>
        <br /><br />
      </div>
    )
  }
}
